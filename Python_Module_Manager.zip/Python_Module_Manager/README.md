# blender_pip

A Blender addon for managing Python modules inside Blender with PIP.
