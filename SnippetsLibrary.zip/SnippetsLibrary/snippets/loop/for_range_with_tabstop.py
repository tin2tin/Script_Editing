for i in range(${1:10}):
    ${2}
    print(${3:i})
    ${0}