def is_list_overlap(l1,l2):
    return(any(n in l1 for n in l2))