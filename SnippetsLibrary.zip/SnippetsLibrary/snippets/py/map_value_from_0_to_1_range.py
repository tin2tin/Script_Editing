#map value between 0 and 1 (sort of normalize to 1)
normval = (${1:val} - ${2:min}) / (${3:max} - ${2:min})