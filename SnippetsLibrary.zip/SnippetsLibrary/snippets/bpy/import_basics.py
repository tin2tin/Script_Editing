import bpy
import os
from mathutils import Vector
C = bpy.context
D = bpy.data
scn = C.scene