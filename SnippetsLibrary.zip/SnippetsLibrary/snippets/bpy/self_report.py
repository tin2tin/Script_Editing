mess = ''
self.report({'INFO'}, mess)#WARNING, ERROR