#interact mode to inspect variables
import code
code.interact(local=locals())

#with local and global variables
import code
namespace = globals().copy()
namespace.update(locals())
code.interact(local=namespace)

#oneliner
__import__('code').interact(local=dict(globals(), **locals()))