# console_easy_text_edit-Blender
create an usual text editor behaviour in console

* click directly where you want to move the cursor
* write over a selection
* cut selected text Ctrl+X
* paste over a selection Ctrl+V
* del backspace selection
* select line Ctrl+A
* quick favorite Ctrl+Q
* I added an undo/redo ctrl+Z ctrl+shift+Z
